type typesMap = {
  [key: string]: number;
};

export default typesMap;
